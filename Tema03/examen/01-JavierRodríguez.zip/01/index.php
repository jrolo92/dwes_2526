<?php
    // Incluimos la libreria de funciones
    require_once 'libs/functions.php';

    // incluimos el modelo:
    require_once 'models/index.model.php';

    // Incluimos la vista:
    require_once 'views/index.view.php';
?>