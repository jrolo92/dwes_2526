<?php
    // Cargamos libreria de funciones:
    require_once 'libs/functions.php';

    // Cargamos modelo:
    require_once 'models/create.model.php';

    // Cargamos la vista:
    require_once 'views/index.view.php';
?>