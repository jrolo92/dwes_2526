<?php
    // 1. Cargamos peliculas:
    $peliculas = get_peliculas();
?>