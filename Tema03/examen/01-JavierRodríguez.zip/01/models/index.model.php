<?php
    // Cargamos las películas desde la función
    $peliculas = get_peliculas();
?>