<?php
    // Cargamos libreria de funciones:
    require_once 'libs/functions.php';

    // cargamos modelo:
    require_once 'models/new.model.php';

    // Cargamos la vista:
    require_once 'views/new.view.php';
?>