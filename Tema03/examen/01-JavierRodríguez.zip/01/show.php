<?php
    // Incluimos las funciones:
    require_once 'libs/functions.php';

    // Cargamos el modelo:
    require_once 'models/show.model.php';

    // Cargamos la vista:
    require_once 'views/show.view.php';
?>