<?php
    // Cargamos librería de funciones:
    require_once 'libs/functions.php';

    // Cargamos modelo:
    require_once 'models/edit.model.php';

    // Cargamos vista:
    require_once 'views/edit.view.php';
?>