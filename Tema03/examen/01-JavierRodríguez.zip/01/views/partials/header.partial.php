<header class="pb-3 mb-4 border-bottom">
    <i class="bi bi-stack"></i>
    <span class="fs-6">Examen - CRUD Gestión de Péliculas</span>
</header>