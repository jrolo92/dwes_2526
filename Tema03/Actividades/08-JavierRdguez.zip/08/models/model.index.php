<?php
    /*  
        Actividad 3.3
        Modelo: model.index.php
        Descripción: Declaración de una tabla de libros
        Autor: Javier Rodríguez López  
        Fecha: 22/10/2025
    */

    $libros = get_tabla_libros();


?>