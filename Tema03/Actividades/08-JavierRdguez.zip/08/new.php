<?php
    /*
        Actividad 3.3    
        Controlador: new.php
        Descripción: Va a mostrar un formulario para añadir un nuevo libro
        Autor: Javier Rodríguez López  
        Fecha: 22/10/2025
    */
    
    // Librerías
    include "libs/functions.php";
    
    //Modelo (no es necesario)
    
        
    //Vista
    require_once "views/new.view.php";                                 


?>