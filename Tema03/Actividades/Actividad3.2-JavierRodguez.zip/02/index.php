<?php
    /*
        Actividad 3.2    
        Controlador: index.php
        Descripción: DEclaración de una tabla de libros, array princiapl indexado y secundario asociativo
        Autor: Javier Rodríguez López  
        Fecha: 20/10/2025
    */
        
    //Modelo
    include "models/model.index.php";
        
    //Vista
    include "views/view.index.php";                                 


?>