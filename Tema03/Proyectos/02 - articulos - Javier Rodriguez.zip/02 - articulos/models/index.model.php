<?php

    // Mostramos la tabla de articulos con nuestra funcion:
    $articulos = get_tabla_articulos();

    // Mostramos la tabla de categorias
    $categorias = get_tabla_categorias();
?>