<?php
    // Cargamos libreria de funciones:
    require_once "libs/funciones.php";

    // Cargamos modelo:
    require_once "models/update.model.php";

    // Cargamos vista:
    require_once "views/index.view.php";
?>