<?php

    
    // Librerías
    require_once "libs/funciones.php";

    //Modelo
    require_once "models/show.model.php";
        
    //Vista
    require_once "views/show.view.php";                          


?>