<?php 
    // Cargamos la libreria de funciones:
        require_once "libs/funciones.php";

    // Cargamos el modelo:
    require_once "models/edit.model.php";

    //  Cargamos la vista:
    require_once "views/edit.view.php";
?>