<?php
    // Cargamos libreria de funciones:
    require_once "libs/funciones.php";

    // Cargamos modelo:
    require_once "models/new.model.php";
   

    // Cargamos vista:
    require_once "views/new.view.php";
?>