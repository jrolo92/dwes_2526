<?php

    // Cargamos la libreria de funciones
    require_once "libs/funciones.php";

    // Cargamos el modelo:
    require_once "models/delete.model.php";

    //  Cargamos la vista:
    require_once "views/index.view.php";
?>